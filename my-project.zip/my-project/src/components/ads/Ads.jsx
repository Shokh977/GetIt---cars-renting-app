import React from "react";
import "./ads.css";

export const Ads = () => {
  return (
    <section className="section ads-container">
      <div className="ad-container">
      <p>...No ads added </p>
      </div>
    </section>
  );
};
